// Running at document_start

var observer = new WebKitMutationObserver(function(mutations) {
      mutations.forEach(function(mutation) {
         if ( mutation.addedNodes !== null && mutation.addedNodes.length > 0 ) {
            var tmpMutation = mutation.addedNodes[0];
            if ( tmpMutation.nodeName === 'DIV' && tmpMutation.id === 'sponsored' ) {
               tmpMutation.style.display = 'none';
            }
         }
      });
   });

observer.observe(document, {
        attributes: false,
        childList: true,
        characterData: false,
        subtree: true });