<http://pgl.yoyo.org/as/index.php>:

Site does encourage use of the list, and nowhere could I find terms and
conditions to use the list. Assuming it can be used freely.
